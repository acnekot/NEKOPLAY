# NEKOPLAY 原型交接包

这是给 DeepSeek（或任何代码模型）做原型用的材料。画布里的 `.dc.html` 是专用运行时格式，模型读不懂，所以这里改成规格说明加分阶段提示词。

## 文件
- `SPEC.md`：完整设计规格（设计变量、版面、组件、频谱、歌词、手机端、动效、验收清单）。
- `tokens.css`：设计变量和基础动画，可以直接粘进项目。
- `prompts/01-layout.md`：第 1 轮，版面 + 基础交互（模拟进度）。
- `prompts/02-audio-spectrum.md`：第 2 轮，真实音频 + Web Audio 频谱 + 设置面板。
- `prompts/03-lyrics-polish.md`：第 3 轮，歌词（原文 / 罗马音 / 翻译）+ 键盘与无障碍。
- `data/tracks.json`、`data/sample.lrc`：示例曲目和带罗马音、翻译的示例歌词。

## 用法（建议分三轮，一轮一个新对话）
1. 第 1 轮：新开对话，先粘贴 `SPEC.md` 全文和 `tokens.css` 全文，再粘贴 `prompts/01-layout.md`。把得到的 `index.html` 存下来，用浏览器直接打开检查。
2. 第 2 轮：新开对话，先粘贴上一轮完整的 `index.html`，再粘贴 `prompts/02-audio-spectrum.md`；如果它需要规格细节，再补发 `SPEC.md` 第 4 节。
3. 第 3 轮：同理，粘贴上一轮的 `index.html` + `prompts/03-lyrics-polish.md`，需要时补发 `SPEC.md` 第 6、7 节和 `data/sample.lrc`。

## 小技巧
- 每轮都要求「输出完整文件」。如果模型开始省略代码，回复「不要省略，输出完整的 index.html」。
- 输出被截断时，回复「从上一段断开的位置继续，不要重复已输出的内容」。
- 单文件超过约 1500 行时，可以让它拆成 `index.html`、`style.css`、`app.js` 三个文件，再逐个文件迭代。
- 验证顺序：先看版面是否像规格，再看交互，最后看动效；发现问题时直接引用 `SPEC.md` 的章节号反馈，例如「按 SPEC 3.3 播放栏高度应为 109px」。
- 真实音频和频谱需要用 `<input type="file">` 选本地音乐文件，直接双击 index.html 就能用，不需要服务器。
