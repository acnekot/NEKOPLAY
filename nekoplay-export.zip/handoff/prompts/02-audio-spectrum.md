# 第 2 轮：真实音频 + 频谱 + 设置面板

（先发上一轮得到的完整 index.html，再发下面这段。）

在上一轮的 index.html 基础上，保持现有结构和样式不变，增加下面的功能，并输出完整的 index.html（不要省略任何代码）。

## 1. 导入并播放真实音乐
- 「导入音乐」按钮触发 `<input type="file" multiple accept="audio/*">`，选中的文件追加到队列。
- 曲名取文件名（去掉扩展名），艺人写「本地文件」，时长用 `<audio>` 的 `loadedmetadata` 获得，格式取扩展名大写，采样率用 `AudioContext.sampleRate` 显示。
- 用一个 `<audio>` 元素播放，进度滑块、已播时间、总时长、音量、顺序 / 随机 / 单曲都改为使用真实的 `audio.currentTime` 和事件（`timeupdate`、`ended`）。
- 队列里原有的示例曲目没有音频文件，播放它们时保持上一轮的模拟计时。

## 2. 频谱背景层（SPEC 第 4 节）
- 用 Web Audio API：`AudioContext` → `MediaElementAudioSourceNode` → `AnalyserNode`（`fftSize = 2048`，`smoothingTimeConstant = 0.8`）→ destination。首次点击播放时再创建 AudioContext。
- 每帧用 `requestAnimationFrame` 读取 `getByteFrequencyData`，按对数刻度（约 30 Hz–16 kHz）归并为 N 根柱子（N 取 24 / 48 / 96），把结果写到每根柱子的 `transform: scaleY(...)`。
- 播放示例曲目（没有真实音频）时，改用 tokens.css 里的 CSS 动画 `eq` 作为模拟频谱。
- 暂停时柱子平滑落到 scaleY(.06)。
- 柱子 DOM 只在柱数变化时重建，不要每帧重建。

## 3. 「频谱设置」面板
- 按 SPEC 第 4 节做出面板，8 个设置项全部生效：显示、样式（柱状 / 细线 / 镜像）、位置（底部 / 铺满）、柱数、速度（只影响模拟动画的周期，真实频谱忽略）、透明度、高度（最高 320px）、颜色。
- 所有设置保存到 `localStorage` 的 `nekoplay.spectrum`，刷新后恢复；「恢复默认」清空。
- 面板可用 Esc 关闭，打开时焦点进入面板，关闭后焦点回到「频谱设置」按钮。

## 4. 自查
- 对照 SPEC 第 10 节验收清单，列出本轮完成和未完成的条目。
