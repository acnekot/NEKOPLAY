# 第 1 轮：版面和基础交互

（先把 SPEC.md 和 tokens.css 的全文发给 DeepSeek，再发下面这段。）

你是资深前端工程师。请严格按 SPEC.md 和 tokens.css，做 NEKOPLAY 本地音乐播放器的桌面端 + 手机端原型。

## 技术要求
- 单个 index.html，原生 HTML + CSS + JavaScript，不用框架、不用构建工具、不依赖外部库；字体可以用 Google Fonts 的 `<link>`（Inter、Noto Sans SC、JetBrains Mono）。
- 样式写在 `<style>`，使用 tokens.css 里的变量；脚本写在 `<script>`，用一个 `state` 对象 + `render()` 函数管理状态，保持可读。
- 响应式：≥ 1000px 走桌面布局，< 1000px 走手机布局（SPEC 第 7 节）。

## 本轮范围
1. 顶栏、主区左右两栏、吸底播放栏，按 SPEC 第 3 节实现。
2. 封面用 CSS 几何图案，按曲目序号 % 4 取款式（SPEC 第 5 节）。
3. 数据用 data/tracks.json 的内容（直接内嵌到脚本里）。
4. 队列：当前曲目高亮 + 跳动小音柱，点击切歌，搜索框实时筛选，无结果时显示空状态。
5. 播放控制：播放 / 暂停、上一首 / 下一首（已播超过 3 秒时「上一首」回到开头）、进度滑块可拖动、顺序 / 随机 / 单曲三种模式、音量滑块。本轮用 `setInterval` 每秒模拟进度，不播放真实声音。
6. 「歌词」标签页先只做空状态。
7. 进入动效 `.rise`，以及 `prefers-reduced-motion` 的降级。
8. 先不做频谱和歌词，留出频谱背景层的 DOM 容器（`#spectrum`）。

## 输出要求
- 只输出一个完整的 index.html，不要省略任何代码，不要写「其余部分同上」。
- 输出前对照 SPEC 第 10 节验收清单自查，最后用 5 行以内列出尚未实现的条目。
